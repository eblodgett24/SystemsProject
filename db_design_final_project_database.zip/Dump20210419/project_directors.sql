-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: project
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `directors`
--

DROP TABLE IF EXISTS `directors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(45) DEFAULT NULL,
  `lastName` varchar(45) DEFAULT NULL,
  `dateOfBirth` datetime DEFAULT NULL,
  `likes` int DEFAULT NULL,
  `profilePicture` varchar(200) DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directors`
--

LOCK TABLES `directors` WRITE;
/*!40000 ALTER TABLE `directors` DISABLE KEYS */;
INSERT INTO `directors` VALUES (1,'Ridley','Scott','1937-11-30 00:00:00',38,'https://m.media-amazon.com/images/M/MV5BMGJkOGM5OWEtNDYxMy00Njg4LWExNjAtY2ZlNWNlNzVhNDk4XkEyXkFqcGdeQXVyNDkzNTM2ODg@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(2,'James','Cameron','1954-08-16 00:00:00',56,'https://m.media-amazon.com/images/M/MV5BMjI0MjMzOTg2MF5BMl5BanBnXkFtZTcwMTM3NjQxMw@@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(3,'Alan','J. Pakula','1928-04-07 00:00:00',49,'https://m.media-amazon.com/images/M/MV5BOTZkMzA4ZjktYWI1NS00NjQxLThiZmMtZDllZTJkYTk1ZDEyXkEyXkFqcGdeQXVyMTc4MzI2NQ@@._V1_UY317_CR35,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(4,'Mary','Harron','1953-01-12 00:00:00',24,'https://m.media-amazon.com/images/M/MV5BZDJhN2U5MzYtNDlkYS00YzE4LWJhZWItY2Q4NzYzMzM2YjFiXkEyXkFqcGdeQXVyMjA4NjQ3ODI@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(5,'Alex','Garland','1970-05-26 00:00:00',15,'https://m.media-amazon.com/images/M/MV5BMTU1ODcxMzA2NF5BMl5BanBnXkFtZTgwNjc2NDk3NTM@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(6,'Denis','Villeneuve','1967-10-03 00:00:00',31,'https://m.media-amazon.com/images/M/MV5BMzU2MDk5MDI2MF5BMl5BanBnXkFtZTcwNDkwMjMzNA@@._V1_UY317_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(7,'Edgar','Wright','1974-04-18 00:00:00',18,'https://m.media-amazon.com/images/M/MV5BMTMxMjgyMjQ4NF5BMl5BanBnXkFtZTcwMTU0ODk2Mw@@._V1_UY317_CR6,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(8,'Robert','Zemeckis','1951-05-14 00:00:00',39,'https://m.media-amazon.com/images/M/MV5BMTgyMTMzMDUyNl5BMl5BanBnXkFtZTcwODA0ODMyMw@@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(9,'Chris','Peckover','1981-03-10 00:00:00',33,'https://m.media-amazon.com/images/M/MV5BNTg0OTA0MWUtMDFmOS00M2U5LWJkNmItZTYxZGVhZmQ3ZmE2XkEyXkFqcGdeQXVyMjQwMDg0Ng@@._V1_UY317_CR51,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(10,'Spike','Lee','1957-03-20 00:00:00',24,'https://m.media-amazon.com/images/M/MV5BMTgyMTEyNDgxOF5BMl5BanBnXkFtZTcwNTkzMTA3Nw@@._V1_UY317_CR12,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(11,'Adam','Wingard','1982-12-03 00:00:00',52,'https://m.media-amazon.com/images/M/MV5BMTQxNDc2OTM1OF5BMl5BanBnXkFtZTcwNTUzODg1OA@@._V1_UY317_CR3,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(12,'S. Craig','Zahler','1973-01-23 00:00:00',15,'https://m.media-amazon.com/images/M/MV5BYzJiZTAyYjMtNDE1MC00NmJlLWE0NzktMDk3Zjg2YTZmNGNkXkEyXkFqcGdeQXVyNjUwNzk3NDc@._V1_UY317_CR20,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(13,'Paul','Thomas Anderson','1970-06-26 00:00:00',28,'https://m.media-amazon.com/images/M/MV5BMTQwNjc5NjY2NV5BMl5BanBnXkFtZTcwNDIxMzg1MQ@@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(14,'Olivia','Wilde','1984-03-10 00:00:00',38,'https://m.media-amazon.com/images/M/MV5BMTg5NTc1NzgwOV5BMl5BanBnXkFtZTcwMTcyMjIzMQ@@._V1_UY317_CR19,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(15,'Alfonso','Cuaron','1961-11-28 00:00:00',46,'https://m.media-amazon.com/images/M/MV5BMjA0ODY4OTk4Nl5BMl5BanBnXkFtZTcwNTkxMzYyMg@@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(16,'Lars','Klevberg','1980-03-12 00:00:00',34,'https://media.elcinema.com/uploads/_315x420_e32a3237b08ec5eb8d69d4d336cbdade401001fff4589ec4b48f0baee4ffe851.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(17,'Gaspar','Noe','1963-12-27 00:00:00',54,'https://m.media-amazon.com/images/M/MV5BMjA1ODY2NTg3NF5BMl5BanBnXkFtZTYwOTMwNzA2._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(18,'Jonathan','Lynn','1943-04-03 00:00:00',48,'https://m.media-amazon.com/images/M/MV5BNTgwNzUyNzMxN15BMl5BanBnXkFtZTgwODQwNzY1MzE@._V1_UY317_CR174,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(19,'Michael','Mann','1943-02-05 00:00:00',45,'https://m.media-amazon.com/images/M/MV5BMTU2MjMzODY3Ml5BMl5BanBnXkFtZTYwNjE0OTMz._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(20,'Steven','Soderbergh','1963-01-14 00:00:00',33,'https://m.media-amazon.com/images/M/MV5BMTQwMjE3ODU1NV5BMl5BanBnXkFtZTYwMzc3MDIz._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-07 16:57:01','2021-04-07 16:57:01'),(21,'Tim','Miller','1964-10-10 00:00:00',45,'https://m.media-amazon.com/images/M/MV5BMTk4NjMyNzY3MV5BMl5BanBnXkFtZTgwNDY0Nzg0ODE@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(22,'Neil','Marshall','1970-05-25 00:00:00',24,'https://m.media-amazon.com/images/M/MV5BMmZmODIyMmUtOGI5My00YjMxLTlhZmYtNTkwNmJkZmM1Nzc1XkEyXkFqcGdeQXVyMjA0ODMwOQ@@._V1_UY317_CR131,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(23,'Mike','Flanagan','1978-05-20 00:00:00',31,'https://m.media-amazon.com/images/M/MV5BYzk4YzQ0NzAtYzkwZS00N2I1LWE2M2UtMmQ5MzZkMTdkNWY1XkEyXkFqcGdeQXVyMTU2NTcyMg@@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(24,'Nicolas','Refn','1970-09-29 00:00:00',29,'https://m.media-amazon.com/images/M/MV5BOTI3NzAzMTAwMl5BMl5BanBnXkFtZTcwNzM5MjQxNw@@._V1_UY317_CR4,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(25,'Christopher','Nolan','1970-07-30 00:00:00',16,'https://m.media-amazon.com/images/M/MV5BNjE3NDQyOTYyMV5BMl5BanBnXkFtZTcwODcyODU2Mw@@._V1_UY317_CR7,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(26,'Michel','Gondry','1963-05-08 00:00:00',39,'https://m.media-amazon.com/images/M/MV5BMjEwNDg3MDA1MF5BMl5BanBnXkFtZTcwMDAxMzc1MQ@@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(27,'Richard','Linklater','1960-07-30 00:00:00',56,'https://m.media-amazon.com/images/M/MV5BMTQ0Mzc2NzY0Ml5BMl5BanBnXkFtZTcwOTI3OTI5MQ@@._V1_UY317_CR4,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(28,'Fede','Alvarez','1978-02-09 00:00:00',37,'https://m.media-amazon.com/images/M/MV5BOWUwYmVkMmEtZGJkMS00NWE1LWEwYzktN2NlOGM3OWZiM2RkXkEyXkFqcGdeQXVyMjc5NDMyMw@@._V1_UY317_CR11,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(29,'Stanley','Kubrick','1928-07-26 00:00:00',46,'https://m.media-amazon.com/images/M/MV5BMTIwMzAwMzg1MV5BMl5BanBnXkFtZTYwMjc4ODQ2._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(30,'Yorgos','Lanthimos','1973-05-27 00:00:00',13,'https://m.media-amazon.com/images/M/MV5BMWYwMTVlOGMtYTQzNi00NzM4LTliNDgtZWU4Zjc4YjQ2NDJmXkEyXkFqcGdeQXVyNTQ3MDc0NTg@._V1_UY317_CR175,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(31,'Paul','Schrader','1946-07-22 00:00:00',32,'https://m.media-amazon.com/images/M/MV5BMTc0MTUwNDM0OV5BMl5BanBnXkFtZTcwMTIzMzM5MQ@@._V1_UY317_CR10,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(32,'Nicholas','Stoller','1976-03-19 00:00:00',35,'https://m.media-amazon.com/images/M/MV5BMTY1MDMxODIyMV5BMl5BanBnXkFtZTgwNTk3ODUzMTE@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-11 15:14:43','2021-04-11 15:14:43'),(33,'Jordan','Peele','1979-02-21 00:00:00',59,'https://m.media-amazon.com/images/M/MV5BOGYzMTdiMTAtZjkwZi00NmYwLWE5MTYtNmY1ZmJlMWY4ZGM0XkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-14 01:04:42','2021-04-14 01:04:42'),(34,'Jeremy','Saulnier','1976-06-10 00:00:00',23,'https://m.media-amazon.com/images/M/MV5BMTM5NjI1NjczNF5BMl5BanBnXkFtZTgwMDkyNzMxMTE@._V1_UY317_CR99,0,214,317_AL_.jpg','2021-04-14 01:04:42','2021-04-14 01:04:42'),(35,'John','Carpenter','1948-01-16 00:00:00',39,'https://m.media-amazon.com/images/M/MV5BMTAzMzgwNDgzODBeQTJeQWpwZ15BbWU4MDA2OTk2NDEx._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-14 01:04:42','2021-04-14 01:04:42'),(36,'David','Mackenzie','1966-05-10 00:00:00',10,'https://m.media-amazon.com/images/M/MV5BODc4NDI2MjMyNl5BMl5BanBnXkFtZTgwMDg0Njc3OTE@._V1_UY317_CR131,0,214,317_AL_.jpg','2021-04-14 01:04:42','2021-04-14 01:04:42'),(37,'James','Wan','1977-02-26 00:00:00',41,'https://m.media-amazon.com/images/M/MV5BOTZlMGZiZTYtZGY0Ni00OTliLTg1ZDctYjJiNDQxNjc5OGQ5XkEyXkFqcGdeQXVyNTI5NjIyMw@@._V1_UY99_CR38,0,99,99_AL_.jpg','2021-04-14 01:04:42','2021-04-14 01:04:42'),(38,'Shane','Black','1961-12-16 00:00:00',15,'https://m.media-amazon.com/images/M/MV5BMTM2ODI3NzkyNl5BMl5BanBnXkFtZTYwMDQ3OTYz._V1_UY317_CR2,0,214,317_AL_.jpg','2021-04-14 01:04:42','2021-04-14 01:04:42'),(39,'David','Robert Mitchell','1974-10-19 00:00:00',15,'https://m.media-amazon.com/images/M/MV5BNTg4MTE2MzI2MF5BMl5BanBnXkFtZTcwOTQ2MDk0Mw@@._V1_UX214_CR0,0,214,317_AL_.jpg','2021-04-14 01:04:42','2021-04-14 01:04:42');
/*!40000 ALTER TABLE `directors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-19 11:27:07
