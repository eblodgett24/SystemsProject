-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: project
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `films`
--

DROP TABLE IF EXISTS `films`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `films` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `releaseDate` datetime DEFAULT NULL,
  `budget` int DEFAULT NULL,
  `gross` int DEFAULT NULL,
  `genre` enum('ACTION','COMEDY','DRAMA','HORROR','MUSICAL','MYSTERY','SCI-FI','THRILLER') DEFAULT NULL,
  `rating` enum('G','PG','PG-13','R') DEFAULT NULL,
  `likes` int DEFAULT NULL,
  `profilePicture` varchar(200) DEFAULT NULL,
  `directorID` int DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `films_to_director_idx` (`directorID`) /*!80000 INVISIBLE */,
  KEY `SECONDARY` (`title`),
  CONSTRAINT `films_to_director` FOREIGN KEY (`directorID`) REFERENCES `directors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `films`
--

LOCK TABLES `films` WRITE;
/*!40000 ALTER TABLE `films` DISABLE KEYS */;
INSERT INTO `films` VALUES (1,'Alien','1979-05-25 00:00:00',11000000,106285522,'HORROR','R',134,'https://m.media-amazon.com/images/I/41ltBoq45nL._AC_.jpg',1,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(2,'Aliens','1986-07-14 00:00:00',18500000,131060248,'ACTION','R',51,'https://i.pinimg.com/736x/ef/25/15/ef25153c3722a291ee9fd24dafc891d7.jpg',2,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(3,'All The Presidents Men','1976-04-05 00:00:00',8500000,70600000,'DRAMA','PG',176,'https://images-na.ssl-images-amazon.com/images/I/511wBH5EH4L._AC_.jpg',3,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(4,'American Psycho','2000-04-14 00:00:00',7000000,34266564,'HORROR','R',107,'https://cdn.shopify.com/s/files/1/0057/3728/3618/products/f85ee5ef68c6266f73cf11f6c599cffd_9c1132bb-9c5f-41c8-bd6f-f35db9a6a1a6_480x.progressive.jpg?v=1573653978',4,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(5,'Annihilation','2018-02-23 00:00:00',40000000,43070915,'SCI-FI','R',94,'https://i.pinimg.com/originals/42/72/84/4272849166f80da9d5e2d9fbf05257ca.jpg',5,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(6,'Arrival','2016-09-01 00:00:00',47000000,203388186,'SCI-FI','PG-13',90,'https://movieposters2.com/images/1423305-b.jpg',6,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(7,'Baby Driver','2017-06-28 00:00:00',34000000,226945087,'ACTION','PG-13',92,'https://img.moviepostershop.com/baby-driver-movie-poster-2017-1010777522.jpg',7,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(8,'Back To The Future','1985-07-03 00:00:00',19000000,381906762,'ACTION','PG-13',247,'https://cdn.europosters.eu/image/750/posters/back-to-the-future-i2795.jpg',8,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(9,'Better Watch Out','2017-10-06 00:00:00',3000000,176288,'HORROR','R',249,'https://www.wellgousa.com/sites/default/files/2018-05/406x600_9.jpg',9,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(10,'BlacKkKlansman','2018-08-10 00:00:00',15000000,93400823,'DRAMA','R',195,'https://images-na.ssl-images-amazon.com/images/I/91fwIBlXA5L._AC_SY879_.jpg',10,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(11,'Blade Runner','1982-06-25 00:00:00',30000000,41676878,'SCI-FI','R',198,'https://images-na.ssl-images-amazon.com/images/I/51abpgBmt6L._AC_.jpg',1,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(12,'Blade Runner 2049','2017-10-06 00:00:00',150000000,259304838,'SCI-FI','R',232,'https://images-na.ssl-images-amazon.com/images/I/71NPmBOdq7L._AC_SL1333_.jpg',6,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(13,'Blair Witch','2016-09-16 00:00:00',5000000,45173154,'HORROR','R',85,'https://cdn.shopify.com/s/files/1/0747/3829/products/mL0713_1024x1024.jpg?v=1571445159',11,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(14,'Bone Tomahawk','2015-09-25 00:00:00',1800000,382579,'HORROR','R',55,'https://i.pinimg.com/736x/f8/66/9a/f8669acb72bd959811e238eafe3e255f.jpg',12,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(15,'Boogie Nights','1997-10-10 00:00:00',15000000,43101594,'DRAMA','R',208,'https://images-na.ssl-images-amazon.com/images/I/51UUpxhXNQL._AC_.jpg',13,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(16,'Booksmart','2019-05-24 00:00:00',6000000,24959607,'COMEDY','R',101,'https://images-na.ssl-images-amazon.com/images/I/81ThnthuDIL._AC_SY741_.jpg',14,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(17,'Children Of Men','2006-12-25 00:00:00',76000000,70595464,'SCI-FI','R',104,'https://horrornews.net/wp-content/uploads/2014/09/Children-Of-Men-poster-1.jpg',15,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(18,'Childs Play','2019-06-21 00:00:00',10000000,44907074,'HORROR','R',197,'https://images-na.ssl-images-amazon.com/images/I/91y3BbvBBpL._AC_SY741_.jpg',16,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(19,'Climax','2019-03-01 00:00:00',2900000,2027391,'HORROR','R',191,'https://images-na.ssl-images-amazon.com/images/I/61z4mC8Zf5L._AC_SL1360_.jpg',17,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(20,'Clue','1985-12-13 00:00:00',15000000,14643997,'COMEDY','PG',90,'https://img.moviepostershop.com/clue-movie-poster-1985-1020374536.jpg',18,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(21,'Collateral','2004-08-06 00:00:00',65000000,220926695,'ACTION','R',58,'https://images-na.ssl-images-amazon.com/images/I/41w%2BfjRUmfL._AC_.jpg',19,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(22,'Contagion','2011-09-09 00:00:00',60000000,136515867,'THRILLER','PG-13',150,'https://miro.medium.com/max/314/0*ElXfTu3lbPtQmKYG.jpg',20,'2021-04-07 19:54:00','2021-04-07 19:54:00'),(23,'Deadpool','2016-02-12 00:00:00',58000000,782836791,'ACTION','R',56,'https://i.ebayimg.com/images/g/QEYAAOSw4DJYmmOQ/s-l400.jpg',21,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(24,'The Descent','2006-08-04 00:00:00',4800000,57130027,'HORROR','R',106,'https://images-na.ssl-images-amazon.com/images/I/519Jj37SYtL._AC_.jpg',22,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(25,'Doctor Sleep','2019-11-08 00:00:00',45000000,72381712,'HORROR','R',101,'https://images-na.ssl-images-amazon.com/images/I/71qEsNpn-pL._AC_SL1500_.jpg',23,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(26,'Dredd','2012-09-21 00:00:00',45000000,41037742,'ACTION','R',78,'https://images-na.ssl-images-amazon.com/images/I/51h-i1qS4PL._AC_.jpg',5,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(27,'Drive','2011-09-16 00:00:00',15000000,77187281,'ACTION','R',157,'https://i.pinimg.com/originals/33/72/6e/33726e086fd631da13160fa503381b81.jpg',24,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(28,'Dunkirk','2017-07-21 00:00:00',100000000,526949403,'ACTION','PG-13',146,'https://images-na.ssl-images-amazon.com/images/I/61jphewUR6L._AC_SL1111_.jpg',25,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(29,'Eternal Sunshine Of The Spotless Mind','2004-03-19 00:00:00',20000000,74036715,'DRAMA','R',53,'https://images-na.ssl-images-amazon.com/images/I/51%2Bwf-vBCUL._AC_.jpg',26,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(30,'Everybody Wants Some!!','2016-03-30 00:00:00',10000000,4644472,'COMEDY','R',111,'https://cdn.shopify.com/s/files/1/1416/8662/products/everybody_wants_some_2016_german_a1_original_film_art_a.jpg?v=1562543595',27,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(31,'Evil Dead','2013-04-05 00:00:00',17000000,97542952,'HORROR','R',140,'https://www.joblo.com/assets/images/oldsite/posters/images/full/new-evil-dead-poster.jpg',28,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(32,'Ex Machina','2015-04-24 00:00:00',15000000,36869414,'SCI-FI','R',51,'https://images-na.ssl-images-amazon.com/images/I/616MblXG9GL._AC_SY741_.jpg',5,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(33,'Eyes Wide Shut','1999-07-16 00:00:00',65000000,162242684,'THRILLER','R',235,'https://cdn.shopify.com/s/files/1/1416/8662/products/eyes_wide_shut_1999_advance_original_film_art_f_1200x.jpg?v=1587504689',29,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(34,'The Favourite','2018-11-23 00:00:00',15000000,95918706,'COMEDY','R',145,'https://i.pinimg.com/originals/63/73/d6/6373d688b658d5305e7a590dcc7bc1a7.jpg',30,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(35,'First Reformed','2018-05-18 00:00:00',3500000,3862498,'DRAMA','R',147,'http://static1.squarespace.com/static/5782ddca03596e5098ee998b/t/5b09e95e6d2a73781c027b14/1527376240291/first_reformed_poster_285.jpg?format=1500w',31,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(36,'Forgetting Sarah Marshall','2008-04-18 00:00:00',30000000,105833257,'COMEDY','R',148,'https://images-na.ssl-images-amazon.com/images/I/51ed-VqmxQL._AC_.jpg',32,'2021-04-11 23:59:50','2021-04-11 23:59:50'),(37,'Get Out','2017-02-24 00:00:00',4500000,255589157,'HORROR','R',237,'https://images-na.ssl-images-amazon.com/images/I/71A-EPdSNaL._AC_SY741_.jpg',33,'2021-04-15 11:43:34','2021-04-15 11:43:34'),(38,'Green Room','2016-04-15 00:00:00',5000000,3769214,'THRILLER','R',146,'https://cdn.shopify.com/s/files/1/0558/2081/products/green_room.jpg?v=1581476693',34,'2021-04-15 11:43:34','2021-04-15 11:43:34'),(39,'The Guest','2014-09-17 00:00:00',5000000,2700051,'THRILLER','R',121,'https://silverscreenqueen.files.wordpress.com/2015/08/the-guest-poster.jpg',11,'2021-04-15 11:43:34','2021-04-15 11:43:34'),(40,'Halloween','1978-10-25 00:00:00',325000,47160000,'HORROR','R',127,'https://images-na.ssl-images-amazon.com/images/I/41yzEOzjm8L._AC_.jpg',35,'2021-04-15 11:43:34','2021-04-15 11:43:34'),(41,'Hell Or High Water','2016-08-12 00:00:00',12000000,37879877,'ACTION','R',63,'http://www.limitedruns.com/media/cache/bf/86/bf862a2e3741661722b03615fe96cd44.jpg',36,'2021-04-15 11:43:34','2021-04-15 11:43:34'),(42,'Inception','2010-07-13 00:00:00',160000000,836836967,'ACTION','PG-13',139,'https://images-na.ssl-images-amazon.com/images/I/611ixoDpRLL._AC_.jpg',25,'2021-04-15 11:43:34','2021-04-15 11:43:34'),(43,'Inherent Vice','2014-12-12 00:00:00',20000000,14710975,'DRAMA','R',178,'https://images-na.ssl-images-amazon.com/images/I/51pB39pXoBL._AC_.jpg',13,'2021-04-15 11:43:34','2021-04-15 11:43:34'),(44,'Insidious','2011-04-01 00:00:00',1500000,99557032,'HORROR','PG-13',207,'https://miro.medium.com/max/500/1*I9zDkUL5PfD7aT0O2Zk8mg.jpeg',37,'2021-04-15 11:43:34','2021-04-15 11:43:34'),(45,'Interstellar','2014-11-05 00:00:00',165000000,701729127,'SCI-FI','PG-13',104,'https://images-na.ssl-images-amazon.com/images/I/516j7Sqay4L._AC_.jpg',25,'2021-04-15 11:43:34','2021-04-15 11:43:34'),(46,'Iron Man 3','2013-05-03 00:00:00',200000000,1214811252,'ACTION','PG-13',229,'https://images-na.ssl-images-amazon.com/images/I/71NN0GU7whL._AC_SY741_.jpg',38,'2021-04-15 11:43:34','2021-04-15 11:43:34'),(47,'It Follows','2015-03-13 00:00:00',1300000,21729511,'HORROR','R',86,'https://i.pinimg.com/originals/11/dc/41/11dc417fac81248d4d1c2b1d44836e8a.jpg',39,'2021-04-15 11:43:34','2021-04-15 11:43:34');
/*!40000 ALTER TABLE `films` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-19 11:27:07
